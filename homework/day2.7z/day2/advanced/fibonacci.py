"""
print n'th element of Fibonacci sequence

Fibonacci sequence:
    1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, ...
"""

n = int(input())

# tip: `for _ in range(n-2)`
